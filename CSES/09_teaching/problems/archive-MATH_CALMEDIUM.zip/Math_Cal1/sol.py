def f(x):
    return x * (x + 1) // 2
def compute_g_x(x):
    if x == 1:
        return 1
    above = x // 2
    below = x - above
    theSquare = below * f(below)
    return theSquare + compute_g_x(above) * 2 + f(above) * below

a = {1, 2, 3, 10, 100, 1000, 1000000, 999999999, 1000000000}
MOD = 1000000007
for x in a:
    print(x, ' ', compute_g_x(x) % MOD)
